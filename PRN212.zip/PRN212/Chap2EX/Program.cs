﻿using System.Diagnostics;
using System.Globalization;

namespace Chap2EX
{
    internal class Program
    {
        static void Ex1()
        {
            Console.WriteLine("Please enter a number between 1 and 10:");
            String input = Console.ReadLine();
            if (int.TryParse(input, out int number) && number >= 1 && number <= 10)
            {
                Console.WriteLine("Valid");


            }
            else
            {
                Console.WriteLine("Invalid");
            }
            Console.ReadLine();
        }
        static void Ex2()
        {
            Console.WriteLine("Enter fist number :");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number");
            int num2 = int.Parse(Console.ReadLine());
            int max = Math.Max(num1, num2);
            Console.WriteLine($"Max of Number{num1} and Number{num1} is : {max}");
            Console.ReadLine();

        }
        static void Ex3()
        {
            Console.WriteLine("Enter width  :");
            int width = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter height :");
            int height = int.Parse(Console.ReadLine());
            if (width > height)
            {
                Console.WriteLine("the  image is landscape");
            }
            else if (height > width)
            {
                Console.WriteLine("the image is portait");
            }
            else {
                Console.WriteLine("the image heiget anf wwidth : equal");
            }

        }
        static void Ex4()
        {

            
            Console.WriteLine("the allowed speed limit:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("the allowed dont speed limit:");
            int b = int.Parse(Console.ReadLine());
            if (a > b)
            {
                int pont = (a - b) / 5;
                Console.WriteLine($"Your car was speeding and the demerit points you have is: { pont}");
                if ( pont > 12)
                {
                    Console.WriteLine("My khoa bang");

                }


            }
            else
            {
                Console.WriteLine("Your car's speed is up to standard");
            }

        }
        static void Ex5()
        {
            int count = 0;

            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0)
                {
                    count++;
                }
            }
        }
        static void Ex6()
        {
            Console.WriteLine("Enter a number:");
            int number = int.Parse(Console.ReadLine());

            int factorial = 1;
            for (int i = 2; i <= number; i++)
            {
                factorial *= i;
            }

            Console.WriteLine($"{number}! = {factorial}");
        }
        static void Ex7()
        {

            Console.WriteLine("Enter a series of numbers separated by comma:");
            string input = Console.ReadLine();

            string[] numbers = input.Split(',');
            int[] intNumbers = Array.ConvertAll(numbers, int.Parse);

            int max = intNumbers.Max();
            Console.WriteLine($"The maximum number is {max}.");
        }
        static void Ex8()
        {
            Console.WriteLine("Enter numberOf like:");
            int numberOfLikes = int.Parse(Console.ReadLine());
            string[] likeby = new string[numberOfLikes];
            for (int i = 0; i < numberOfLikes; i++)
            {
                Console.WriteLine("Enter like by :");
                likeby[i] = Console.ReadLine();

            }
            displayStatus(numberOfLikes, likeby);

        }

        private static void displayStatus(int numberOfLikes, string[] likeby)
        {
            if(numberOfLikes == 0) {
                Console.WriteLine("No on like in status");
            } else if (numberOfLikes == 1)
            {
                Console.WriteLine($"{likeby[0]} like status");
            }else if (numberOfLikes == 2)
            {
                Console.WriteLine($"{likeby[0]} and {likeby[1]} like status");
            }
            else if (numberOfLikes - 2 > 0)
            {
                Console.WriteLine($"{likeby[0]} and {likeby[1]} and orther person like status");
            }
            {

            }
        }
        static void Ex9()
        {
            Console.WriteLine("Enter an input");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int integerValue))
            {
                if (integerValue > 20 && integerValue < 60)
                {
                    Console.WriteLine($"{input}-year-old adult");
                }
                else
                {
                    Console.WriteLine("Input is not in the specified range.");
                }
            }
            else if (double.TryParse(input, out double doubleValue))
            {
                if (doubleValue > 0)
                {
                    Console.WriteLine($"The salary is {input}");
                }
                else
                {
                    Console.WriteLine($"The debt is {input}");
                }
            }
            else
            {
                Console.WriteLine($"The name is {input}");
            }
        }
        static void Ex10()
        {

            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine();

            string[] words = input.Split(' ');
            if (words.Length<=3)
            {



                string firstName = (words.Length > 0) ? words[0] : null;
                string lastName = (words.Length > 0) ? words[words.Length - 1] : null;
                string middleName = (words.Length > 2) ? words[words.Length - 2] : null;
                Console.WriteLine("First Name: " + (string.IsNullOrEmpty(firstName) ? "N/A" : firstName));
                Console.WriteLine("Middle Name: " + (string.IsNullOrEmpty(middleName) ? "N/A" : middleName));
                Console.WriteLine("Last Name: " + (string.IsNullOrEmpty(lastName) ? "N/A" : lastName));
            }
            else if (words.Length>=4){
                Console.WriteLine("ban da vuot qua");
            }

            
        }
        static void Main(string[] args)
        {
        
            Ex10();
          
        }
    }
}
