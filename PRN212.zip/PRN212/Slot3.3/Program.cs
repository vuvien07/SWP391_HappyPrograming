﻿using System;

public interface IFirst
{
    void Print();
    void Display();
}

public interface ISecond
{
    void Print();
}

public class MyClass : IFirst, ISecond
{
    // Implementing the Display method from IFirst
    public void Display()
    {
        Console.WriteLine("Display method");
    }

    // Explicitly implementing the Print method from IFirst
    void IFirst.Print()
    {
        Console.WriteLine("IFirst's Print method");
    }

    // Explicitly implementing the Print method from ISecond
    void ISecond.Print()
    {
        Console.WriteLine("ISecond's Print method");
    }
}

class Program
{
    static void Main(string[] args)
    {
        MyClass obj = new MyClass();
        obj.Display();

        IFirst first = obj;
        first.Print();

        ISecond second = obj;
        second.Print();

        Console.ReadLine();
    }
}
