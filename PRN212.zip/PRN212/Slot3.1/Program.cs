﻿using System;

public class MyClass
{
    // Init-Only Property
    public int X { get; init; }

    // Read-Only Auto Property
    public int Y { get; } = 20;

    // Constructor with default values
    public MyClass()
    {
        X = 10;
    }

    // Constructor with parameters
    public MyClass(int x, int y)
    {
        X = x;
        Y = y;
    }
}

class Program
{
    static void Main(string[] args)
    {
        MyClass obj1 = new MyClass();
        Console.WriteLine($"x: {obj1.X}, y: {obj1.Y}");

        // obj1.X = 10; // Error: cannot modify init-only property
        // obj1.Y = 20; // Error: cannot modify read-only property

        MyClass obj2 = new MyClass(30, 40);
        Console.WriteLine($"x: {obj2.X}, y: {obj2.Y}");

        Console.ReadLine();
    }
}
