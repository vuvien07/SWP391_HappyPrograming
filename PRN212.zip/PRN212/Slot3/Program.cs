﻿using System;

class Customer
{
    // Private field
    private int _id;

    // Full property
    public int CustomerID
    {
        get { return _id; }
        set { _id = value; }
    }

    // Automatic property
    public string CustomerName { get; set; } = "New customer";

    // Method to print customer details
    public void Print()
    {
        Console.WriteLine($"ID: {CustomerID}, Name: {CustomerName}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Customer obj = new Customer();
        obj.CustomerID = 1000;
        Console.WriteLine($"ID: {obj.CustomerID}, Name: {obj.CustomerName}");

        obj.CustomerID = 2000;
        obj.CustomerName = "Jack";
        obj.Print();

        Console.ReadLine();
    }
}
