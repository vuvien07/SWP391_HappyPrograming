﻿using System.Runtime.CompilerServices;
using System.Text;

namespace PRN212
{
    internal class Program
    { 
        static void  Mymthod(int a , ref int b ,  out int c) {
            a = 3; b = 4 ; c = 5 ;
            
        }
        static void Main(string[] args)
        {
  

            var myint = 0;
            var mybool = true;
            var String = " hello word";
            Console.WriteLine("Myint is a :{0}", myint.GetType().Name);
            Console.WriteLine("Mybool is a :{0}", mybool.GetType().Name);
            //var
            dynamic myValue = 0;
            Console.WriteLine("MyValue is a :{0}", myValue.GetType().Name);
            myValue = true;
            Console.WriteLine("MyValue is a :{0}",myValue.GetType().Name);
            //dynamic
            double salary = 200.234;
            String name = "Soren";
            //String Interpolation
            //using curly _ brenket syntax
            String str1 = String.Format("Name{0,6},Salary{1,7:N2}",name,salary);
            Console.WriteLine(str1);
            //using  string interpolation
            String  str2 = $"Name{name,7},Salary{salary,8:N2}";
            Console.WriteLine(str2);    
            int  x =1 , y = 2 , z;
            Mymthod(x, ref y, out z);
            Console.WriteLine($"x:{x},y:{y},z:{z}");
            Console.ReadLine();


        }   
    }
}
