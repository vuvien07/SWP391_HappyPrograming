﻿using System;

class Employee
{
    private int id;
    private string name;

    // Constructor
    public Employee(int id, string name)
    {
        this.id = id;
        this.name = name;
    }

    // Properties
    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public int Id
    {
        get { return id; }
        set { id = value; }
    }
}

class Manager : Employee
{
    private string email;

    // Constructor
    public Manager(int id, string name, string email) : base(id, name)
    {
        this.email = email;
    }

    // Property
    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    // Override ToString method
    public override string ToString()
    {
        return $"Id: {Id}, Name: {Name}, Email: {Email}";
    }
}

class Program
{
    static void Main(string[] args)
    {
        Manager jack = new Manager(1000, "Jack", "Jack@gmail.com");
        Console.WriteLine(jack);
        Console.ReadLine();
    }
}
