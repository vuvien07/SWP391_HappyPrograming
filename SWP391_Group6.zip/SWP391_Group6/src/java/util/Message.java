/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author Admin
 */
public class Message {
    public static final String HOST_EMAIL = "vuvthe173552@fpt.edu.vn";
    public static final String HOST_PASSWORD = "muqt sosf eoqr fdhq";
    public static final String GENERATION_PASSWORD = "abcdefgfijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*";
}
