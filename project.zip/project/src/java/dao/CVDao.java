/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.DBContext;
import model.CV;

import java.sql.*;
import java.util.ArrayList;
import model.Notification;

public class CVDao extends DBContext<CV> {

    @Override
    public ArrayList<CV> listAll() {
        ArrayList<CV> cvs = new ArrayList<>();
        try {
            String sql = "SELECT * FROM CV";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                CV cv = new CV(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("status"));
                cvs.add(cv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cvs;
    }

    @Override
    public void insert(CV cv) {
        try {
            String sql = "INSERT INTO CV (title, content, status) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, cv.getTitle());
            statement.setString(2, cv.getContent());
            statement.setString(3, cv.getStatus());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(CV cv) {
        try {
            String sql = "UPDATE CV SET title = ?, content = ?, status = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, cv.getTitle());
            statement.setString(2, cv.getContent());
            statement.setString(3, cv.getStatus());
            statement.setInt(4, cv.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(CV cv) {
        try {
            String sql = "DELETE FROM CV WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, cv.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public CV getCVById(int id) {
        try {
            String sql = "SELECT * FROM CV WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return new CV(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateStatus(int cvId, String status) {
        try {
            String sql = "UPDATE CV SET status = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, status);
            statement.setInt(2, cvId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<CV> getSubmittedCVs() {
        ArrayList<CV> cvs = new ArrayList<>();
        try {
            String sql = "SELECT * FROM CV WHERE status = 'submitted'";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                CV cv = new CV(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("status"));
                cvs.add(cv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cvs;
    }
    public void insertNotification(int userId, String message) {
        String sql = "INSERT INTO Notifications (userId, message, isRead) VALUES (?, ?, 0)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setString(2, message);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Notification> getNotificationsByUserId(int userId) {
        ArrayList<Notification> notifications = new ArrayList<>();
        String sql = "SELECT * FROM Notifications WHERE userId = ? AND isRead = 0";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Notification notification = new Notification(
                    rs.getInt("id"),
                    rs.getInt("userId"),
                    rs.getString("message"),
                    rs.getBoolean("isRead")
                );
                notifications.add(notification);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notifications;
    }

    public void markNotificationsAsRead(int userId) {
        String sql = "UPDATE Notifications SET isRead = 1 WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
     public ArrayList<CV> getCVsByStatus(String status) {
        ArrayList<CV> cvs = new ArrayList<>();
        String sql = "SELECT * FROM CVs WHERE status = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, status);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                CV cv = new CV(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getString("status")
                );
                cvs.add(cv);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cvs;
    }
}