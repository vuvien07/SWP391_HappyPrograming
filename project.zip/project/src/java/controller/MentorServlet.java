/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.CVDao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import model.CV;
import model.Notification;

public class MentorServlet extends HttpServlet {
    private CVDao cvDao = new CVDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            response.sendRedirect("mentor?action=viewProfiles");
            return;
        }

        switch (action) {
            case "viewProfiles":
                Integer userId = (Integer) request.getSession().getAttribute("userId");
                CV cv = cvDao.getCVById(userId);
                request.setAttribute("cv", cv);
                request.getRequestDispatcher("/jsp/viewProfiles.jsp").forward(request, response);
                break;
            case "createCV":
                request.getRequestDispatcher("/jsp/createCV.jsp").forward(request, response);
                break;
            case "viewCVStatus":
                int cvId = Integer.parseInt(request.getParameter("cvId"));
                CV cvStatus = cvDao.getCVById(cvId);
                request.setAttribute("cv", cvStatus);
                request.getRequestDispatcher("/jsp/viewCVStatus.jsp").forward(request, response);
                break;
            case "viewCV":
                cvId = Integer.parseInt(request.getParameter("cvId"));
                CV cvDetail = cvDao.getCVById(cvId);
                request.setAttribute("cv", cvDetail);
                request.getRequestDispatcher("/jsp/viewCV.jsp").forward(request, response);
                break;
            case "notificationMentor":
                userId = (Integer) request.getSession().getAttribute("userId");
                ArrayList<Notification> notifications = cvDao.getNotificationsByUserId(userId);
                cvDao.markNotificationsAsRead(userId);
                request.setAttribute("notifications", notifications);
                request.getRequestDispatcher("/jsp/notificationMentor.jsp").forward(request, response);
                break;
            default:
                response.sendRedirect("index.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("saveCV".equals(action) || "submitCV".equals(action)) {
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String status = "saveCV".equals(action) ? "draft" : "process";
            CV cv = new CV(title, content, status);
            cvDao.insert(cv);

            if ("submitCV".equals(action)) {
                // Notify Manager
                cvDao.insertNotification(1, "New CV submitted by Mentor"); // Assuming manager's userId is 1
                // Notify Mentor
                int userId = (Integer) request.getSession().getAttribute("userId");
                cvDao.insertNotification(userId, "Your CV has been submitted successfully. Please wait for the manager's review.");
            }

            response.sendRedirect("mentor?action=viewCVStatus&cvId=" + cv.getId());
        } else if ("updateCV".equals(action)) {
            int cvId = Integer.parseInt(request.getParameter("cvId"));
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            CV cv = cvDao.getCVById(cvId);
            cv.setTitle(title);
            cv.setContent(content);
            cv.setStatus("process");
            cvDao.update(cv);

            // Notify Manager
            cvDao.insertNotification(1, "Updated CV submitted by Mentor"); // Assuming manager's userId is 1
            // Notify Mentor
            int userId = (Integer) request.getSession().getAttribute("userId");
            cvDao.insertNotification(userId, "Your CV update has been submitted successfully. Please wait for the manager's review.");

            response.sendRedirect("mentor?action=viewCVStatus&cvId=" + cv.getId());
        }
    }
}