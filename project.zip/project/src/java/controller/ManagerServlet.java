/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.CVDao;
import dao.NotificationDao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import model.CV;
import model.Notification;

public class ManagerServlet extends HttpServlet {
    private final CVDao cvDao = new CVDao();
    private final NotificationDao notificationDao = new NotificationDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            response.sendRedirect("manager?action=viewListCV");
            return;
        }

        switch (action) {
            case "viewListCV":
                ArrayList<CV> processCVs = cvDao.getCVsByStatus("process");
                request.setAttribute("processCVs", processCVs);
                request.getRequestDispatcher("/jsp/viewListCV.jsp").forward(request, response);
                break;
            case "viewCVDetail":
                int cvId = Integer.parseInt(request.getParameter("cvId"));
                CV cv = cvDao.getCVById(cvId);
                request.setAttribute("cv", cv);
                request.getRequestDispatcher("/jsp/viewCVDetail.jsp").forward(request, response);
                break;
            default:
                response.sendRedirect("index.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("acceptCV".equals(action) || "rejectCV".equals(action)) {
            int cvId = Integer.parseInt(request.getParameter("cvId"));
            String status = "acceptCV".equals(action) ? "accepted" : "rejected";
            cvDao.updateStatus(cvId, status);

            // Notify Mentor
            CV cv = cvDao.getCVById(cvId);
            notifyMentor(cv.getId(), "Manager has reviewed your CV.");

            response.sendRedirect("manager?action=viewListCV");
        } else if ("viewProfiles".equals(action)) {
            int cvId = Integer.parseInt(request.getParameter("cvId"));
            CV cv = cvDao.getCVById(cvId);
            request.setAttribute("cv", cv);
            request.getRequestDispatcher("/jsp/viewProfiles.jsp").forward(request, response);
        }
    }

    private void notifyMentor(int userId, String message) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setMessage(message);
        notification.setIsRead(false); // Default value, assuming notification is unread initially
        notificationDao.insert(notification);
    }
}